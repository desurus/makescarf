=== WP Easy Paypal Payment Accept ===
Contributors: Ruhul Amin, Tips and Tricks HQ
Donate link: http://www.tipsandtricks-hq.com
Tags: Paypal payment, Accept payment for services or product, PayPal donation, wordpress paypal, paypal for wordpress, paypal plugin for wordpress, paypal integration, paypal 
Requires at least: 3.0
Tested up to: 3.6.1
Stable tag: 3.0
License: GPLv2 or later

Easy to use Wordpress plugin to accept paypal payment for a service or product or donation in one click

== Description ==

Easy to use Wordpress plugin to accept paypal payment for a service or product or donation in one click. Can be used in the sidebar, posts and pages of your site.

For information, detailed documentation and updates, please visit the [WordPress PayPal Payment](http://www.tipsandtricks-hq.com/?p=120) Plugin Page

* Quick installation and setup.
* Easily take payment for a service from your site via PayPal.
* Add multiple payment widget for different services or products.
* Ability to configure which currency you want to use to accept the payment.
* You will need to have your own PayPal account (creating a PayPal account is free).
* Integrate PayPal with your WordPress powered site.
* Accept donation on your WordPress site for a cause.

== Usage ==

There are few ways you can use this plugin:

1. Use the sortcode [wp_paypal_payment] to place the payment accept form.
2. Add the paypal payment widget to your sidebar widgets.
3. Call the function from a template file: <?php echo Paypal_payment_accept(); ?>
4. Use the shortcode with custom parameter option to add multiple different payment widget in different areas of the site.

== Installation ==

1. Unzip and Upload the folder 'WP-accept-paypal-payment' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings and configure the options eg. your email, Subject text etc.
4. See the usage section for details on how to place the paypal payment widget

== Frequently Asked Questions ==

== Screenshots ==

Visit the plugin site at http://www.tipsandtricks-hq.com/?p=120 for screenshots.

== Changelog ==

- 3.0 - WordPress 3.6 compatibility update

Changelog for old versions can be found at the following URL
http://www.tipsandtricks-hq.com/?p=120
